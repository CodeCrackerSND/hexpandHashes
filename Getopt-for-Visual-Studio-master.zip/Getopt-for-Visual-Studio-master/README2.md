getopt
======

GNU getopt for Visual Studio

Copyright
---------

This project contains code from getopt.h and getopt.c from the MinGW
repositories. The license terms from MinGW apply when using these files.

Usage
-----

Copy the file to the include folder in Visual Studio. That should be in
Program Files\Microsoft Visual Studio xxx\VC\include